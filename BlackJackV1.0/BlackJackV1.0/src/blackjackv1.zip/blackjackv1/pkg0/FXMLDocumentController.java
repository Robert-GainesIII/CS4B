/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjackv1.pkg0;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Slider;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.image.ImageView;
import javafx.scene.input.DragEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;

/**
 *
 * @author bobby
 */
public class FXMLDocumentController implements Initializable {
    
    Deck deck = new Deck();
    Player p1 = new Player(1000);
    public ArrayList<Player> players;
    @FXML
    public HBox hbox1;
    @FXML
    public HBox playerbox1;
    @FXML
    private Slider slider;
    @FXML
    private Label moneyLabel;
    @FXML
    private Label betLabel;
    @FXML
    private Button hitButton;
    @FXML
    private TabPane tabPane;
    @FXML
    private Tab player1;
    @FXML
    private Label cardCount;
    @FXML
    private TabPane playerDock;
  
    @FXML
    private void handleButtonAction(ActionEvent event) {
        
        for(Player p : players){
       
        if(p.isUp()){
            System.out.println(players.indexOf(p));
        Card c = deck.draw(p.getCardBox().getWidth(),p.getCardBox().getHeight());
        Pane card = (c.getPane());
        p.addCardCount(c.getValue());
        p.getCardBox().getChildren().add(card);
        p.getCardBox().setAlignment(Pos.CENTER);
        
//        String[] tokens = cardCount.getText().split(" ");
//        if(tokens[2].length() > 1){
//        int a = Integer.parseInt(tokens[2]);
//        int b = a + c.getValue();
        cardCount.setText("Card Count: " + p.getCardCount());
        if(p.getCardCount() > 21){
            if(players.size() > 1){
                players.get(players.indexOf(p) + 1).setTurn(true);
            }
        }
        }
        }
        hbox1.setAlignment(Pos.CENTER);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        moneyLabel.setText(moneyLabel.getText() + p1.getMoney());
        players = new ArrayList<Player>();
        players.add(p1);
        p1.setCardBox(playerbox1);
        p1.setTurn(true);
    }    
   

    @FXML
    private void handleSliderAction(MouseEvent event) {
        int value =(int)slider.getValue();
        betLabel.setText("Bet$$-> " + value);
    }
    
    public void addNewPlayer(){
        Player p = new Player(1000);
        HBox playerBox =  new HBox();
        final Tab tab = new Tab("player " + (playerDock.getTabs().size() + 1));
        HBox hbox = new HBox();
        hbox.setPrefHeight(232.0);
        hbox.setPrefWidth(1000.0);
        p.setCardBox(hbox);
        tab.setContent(hbox);
        playerDock.getTabs().add(tab);
    }

   
    
    
}
