/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjackv1.pkg0;

import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.HBox;

/**
 *
 * @author bobby
 */
public class Player {
    
    private double money;
    
    private int cardCount;
    
    private HBox cardBox;
    
    private boolean myTurn;
    
    public Player(double money){
        this.money = money;
    }

    public double getMoney() {
        return money;
    }

    public void subtractMoney(double money) {
        this.money -= money;
    }

    public int getCardCount() {
        return cardCount;
    }

    public void addCardCount(int card) {
        this.cardCount += card;
        if(cardCount > 21){
            myTurn = false;
            Alert alert = new Alert(AlertType.ERROR);
            alert.setContentText("BUST");
            alert.show();
        }
    }

    public HBox getCardBox() {
        return cardBox;
    }

    public void setCardBox(HBox cardBox) {
        this.cardBox = cardBox;
    }
    
    public void setTurn(boolean a){
        myTurn = a;
    }
    public boolean isUp(){
        return myTurn;
    }
    
    
}
